// src/redux/filters/selectors.js

export const selectNameFilter = (state) => state.filter.filterValue;
